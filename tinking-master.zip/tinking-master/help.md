# HELP ?! 🙋🏼‍♂️

While Tinking aims to be a universal tool, it's still a work in progress, and you may run into issues scraping certain websites.

If you have a bug or a feature request you can directly [submit an issue](https://github.com/baptisteArno/tinking/issues/new/choose).

If you have a question [ask it to the community](https://github.com/baptisteArno/tinking/discussions).

## FAQ

👉 [How to use the generated code?](https://github.com/baptisteArno/tinking-code-starter)
