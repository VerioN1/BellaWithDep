# Privacy Policy

Tinking doesn't gather data in any way. It is just a simple tool that converts clicks to code.

Tinking is devoted to complying with all Chrome Web Store privacy regulations
